module.exports = function(app) {
    // app passes in the express object needed for the route.
    // path passes in a path object needed to find the file. The
    //path module is part of node and needs to be required in the
    //server.js file
    app.get('/api/food', function(req, res) {
        // let filepath = path.resolve('./www/form.html');
        result = {}
        result.username = 'u1';
        result.age = 45;
        result.email = 'e@me.com';
        result.valid = true;

        res.send(result);
    });
}